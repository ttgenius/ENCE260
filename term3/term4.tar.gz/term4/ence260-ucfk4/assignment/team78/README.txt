A Snake & Chef game for the ENCE260 assignmnent.
2016 Semester 2

Date of final submission: 13 October 2016

Team 78
Students: Amanda Deacon (asd35) & Melody Zhu (yzh231)

About the game:
Snake & Chef is an asymmetric two-player twist on the 
classic arcade game Snake. 
 
Player One plays as the Snake, and moves around the board 
using the navswitch to gather food and grow happy and long.
Player Two plays as the Chef, and moves around their own 
board, pushing down on the navswitch to drop food in the 
corresponding location of the Snake's board.

Have fun!
